from setuptools import setup, find_packages

setup(name='hierarchical-generalization',
      license='Brown University',
      author='APRashedAhmed',
      packages=find_packages(),
      )
